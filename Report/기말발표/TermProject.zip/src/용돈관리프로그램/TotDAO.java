package �뵷�������α׷�;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import DB.DBConnectManager;



public class TotDAO {
	
	private static TotDAO totdao;
	TotDAO()
	{
		
	}
	
	public static TotDAO getInstance()
	{
		if(totdao==null)
		{
			totdao=new TotDAO();
		}
		return totdao;
	}
	
	public int InputSum()
	{
		int st=0;
		
		Connection connn=null;
		PreparedStatement pstmtpstmt=null;
		ResultSet rsrs=null;
		
		try
		{
			connn=DBConnectManager.dbConn();
			String sqlsql="SELECT SUM(date) as tot FROM moneyin";
			pstmtpstmt=connn.prepareStatement(sqlsql);
			rsrs=pstmtpstmt.executeQuery();
			while (rsrs.next())
			{
				
				int inputsum=rsrs.getInt("tot");
				
			
				
				st=inputsum;
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DBConnectManager.close(connn,pstmtpstmt,rsrs);
		}
		return st;
	}
	
	public int OutputSum()
	{
		int st=0;
		
		Connection connn=null;
		PreparedStatement pstmtpstmt=null;
		ResultSet rsrs=null;
		
		try
		{
			connn=DBConnectManager.dbConn();
			String sqlsql="SELECT SUM(outdate) as tot FROM moneyout";
			pstmtpstmt=connn.prepareStatement(sqlsql);
			rsrs=pstmtpstmt.executeQuery();
			while (rsrs.next())
			{
				
				int inputsum=rsrs.getInt("tot");
				
			
				
				st=inputsum;
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DBConnectManager.close(connn,pstmtpstmt,rsrs);
		}
		return st;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
