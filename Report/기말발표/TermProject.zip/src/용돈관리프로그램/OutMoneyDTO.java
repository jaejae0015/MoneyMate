package �뵷�������α׷�;

public class OutMoneyDTO {
	private String outmoney_no;
	private String outbigitem;
	private String outsmallitem;
	private int outmoney;
	private String outdate;


	
	public OutMoneyDTO() {
		super();
	}
	public OutMoneyDTO(String outmoney_no, String outbigitem, String outsmallitem, int outmoney, String outdate) {
		this.outmoney_no = outmoney_no;
		this.outbigitem = outbigitem;
		this.outsmallitem = outsmallitem;
		this.outmoney = outmoney;
		this.outdate = outdate;

	}
	public String getoutMoney_no() {
		return outmoney_no;
	}
	public void setoutMoney_no(String outmoney_no) {
		this.outmoney_no = outmoney_no;
	}
	public String getoutBigItem() {
		return outbigitem;
	}
	public void setoutBigItem(String outbigitem) {
		this.outbigitem = outbigitem;
	}
	public String getoutSmallItem() {
		return outsmallitem;
	}
	public void setoutSmallItem(String outsmallitem) {
		this.outsmallitem = outsmallitem;
	}
	public int getoutMoney() {
		return outmoney;
	}
	public void setoutMoney(int outmoney) {
		this.outmoney = outmoney;
	}
	public String getoutDate() {
		return outdate;
	}
	public void setoutDate(String outdate) {
		this.outdate = outdate;
	}
	
	
	@Override
	public String toString() {
		return "OutMoneyDTO [outmoney_no=" + outmoney_no + ", outbigitem=" + outbigitem + ", outsmallitem=" + outsmallitem + ", outmoney=" +  outmoney + ", outdate="
				+ outdate +  "]";
	}
		
	
}