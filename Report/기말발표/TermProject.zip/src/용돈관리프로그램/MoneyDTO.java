package �뵷�������α׷�;

public class MoneyDTO {
	private String money_no;
	private String bigitem;
	private String smallitem;
	private int money;
	private String date;


	
	public MoneyDTO() {
		super();
	}
	public MoneyDTO(String money_no, String bigitem, String smallitem, int money, String date) {
		this.money_no = money_no;
		this.bigitem = bigitem;
		this.smallitem = smallitem;
		this.money = money;
		this.date = date;

	}
	public String getMoney_no() {
		return money_no;
	}
	public void setMoney_no(String money_no) {
		this.money_no = money_no;
	}
	public String getBigItem() {
		return bigitem;
	}
	public void setBigItem(String bigitem) {
		this.bigitem = bigitem;
	}
	public String getSmallItem() {
		return smallitem;
	}
	public void setSmallItem(String smallitem) {
		this.smallitem = smallitem;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	@Override
	public String toString() {
		return "MoneyDTO [money_no=" + money_no + ", bigitem=" + bigitem + ", smallitem=" + smallitem + ", money=" + money + ", date="
				+ date +  "]";
	}
	
	
	
	
	
	
	
}