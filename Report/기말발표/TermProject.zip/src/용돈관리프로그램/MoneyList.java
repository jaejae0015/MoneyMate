package �뵷�������α׷�;
import java.lang.ArrayIndexOutOfBoundsException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.text.DefaultCaret;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.Vector;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JRadioButton;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.demo.PieChartDemo1;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MoneyList extends JFrame {

	private JPanel contentPane;
	private JTable table;
	static MoneyList frame;
	
	
	private MoneyDAO dao;
	private Vector data, col; //data(��������Ʈ), col(���̺��� ���)
	
	private JTextField tfMoney_no;
	private JTextField tfBigItem;
	private JTextField tfSmallItem;
	private JTextField tfMoney;
	private JTextField tfDate;
	
	private JButton btnUpdate;
	private JButton btnDelete;
	private JButton btnSearch;
	private JTextField tfSearch;
	
	//�߰��׸���
	private JPanel panel;
	private JPanel panel_2;
	private JLabel label;
	private JButton button;
	private JLabel label_1;
	private JLabel label_2;
	private JComboBox comboBox;
	private JTextField textField;
	private JTable table_1;
	
	//�Ѽ������������� �ǳ�
	private JPanel panel_3;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	
	//���⺯��
	private JPanel panel_4;
	private JTable table1;
	private OutMoneyDAO outdao;
	private Vector outdata, outcol; //data(��������Ʈ), col(���̺��� ���)
	
	private JTextField tfoMoney_no;
	private JTextField tfoBigItem;
	private JTextField tfoSmallItem;
	private JTextField tfoMoney;
	private JTextField tfoDate;
	private JButton btnoUpdate;
	private JButton btnoDelete;
	private JButton btnoSearch;
	
	private JTextField tfoSearch;
	private JPanel panel_6;
	private JLabel label_14;
	private JButton button_2;
	private JLabel label_15;
	private JLabel label_16;
	private JComboBox comboBox_1;
	private JTextField textField_4;
	private JTable table_2;
	private JTextField textField_5;
	private JLabel label_18;
	private JLabel label_19;
	private JTable table_3;
	
	private ChartDAO chartdao;
	private SelectDAO sdao;
	//���̺��� ���� �÷� ����
	private Vector colcolcol;
	private JPanel panel_9;
	private JPanel panel_10;
	private ChartPanel chartPanel;
	private ChartPanel chartPanel1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new MoneyList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MoneyList() {
		super("�뵷�������α׷�_�뵷��");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1027, 709);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setResizable(false);
        getContentPane().setLayout(null);
		
		//dao ��ü ����
		dao=MoneyDAO.getInstance();
		//���̺��� ���� �÷� ����
		col=new Vector();
		col.add("�׸��ȣ");
		col.add("���׸�");
		col.add("�׸��");
		col.add("�ݾ�");
		col.add("��¥");
		col.add("�ѱݾ�");
		
		
		
		//���� ����Ʈ�� �ҷ���
		//���̺� �� : JTable�� �Էµ� ������
		//JTable �� �Է� ������ ������ :�迭(����, ������ �ȵ�), Object, Vector
		// new DefaultTableModel(������, ����)
		DefaultTableModel model=new DefaultTableModel(dao.listScore(), col){
			
			//���̺� ������ �������� ���ϵ��� ����
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		contentPane.setLayout(null);
		
		panel_3 = new JPanel();
		panel_3.setBounds(0, 0, 1021, 57);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		panel_3.setBackground(SystemColor.activeCaption);
		
		label_3 = new JLabel("\uCD1D\uC218\uC785");
		label_3.setFont(new Font("����ü", Font.BOLD, 17));
		label_3.setBounds(40, 10, 51, 36);
		panel_3.add(label_3);
		
		
		
		
		//�ǳ�
		//pra totdao =new pra();
		TotDAO totdao=new TotDAO();
		JLabel lblNewLabel_6 = new JLabel();
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("����", Font.BOLD, 18));
		lblNewLabel_6.setText(Integer.toString(totdao.InputSum()));
		lblNewLabel_6.setBounds(103, 15, 126, 24);
		panel_3.add(lblNewLabel_6);
		//System.out.println(totdao.InputSum());
		
		label_4 = new JLabel("-");
		label_4.setFont(new Font("����ü", Font.BOLD, 26));
		label_4.setBounds(241, 19, 20, 21);
		panel_3.add(label_4);
		
		
		label_5 = new JLabel("\uCD1D\uC9C0\uCD9C");
		label_5.setFont(new Font("����ü", Font.BOLD, 17));
		label_5.setBounds(273, 10, 51, 36);
		panel_3.add(label_5);
		
		label_18 = new JLabel();
		label_18.setText("hello");
		label_18.setHorizontalAlignment(SwingConstants.CENTER);
		label_18.setFont(new Font("����", Font.BOLD, 18));
		label_18.setText(Integer.toString(totdao.OutputSum()));
		label_18.setBounds(336, 15, 126, 24);
		panel_3.add(label_18);
		
		
		label_6 = new JLabel("=");
		label_6.setFont(new Font("����ü", Font.BOLD, 26));
		label_6.setBounds(464, 19, 20, 21);
		panel_3.add(label_6);
		
		label_19 = new JLabel();
		label_19.setText(Integer.toString(totdao.InputSum()-totdao.OutputSum()));
		label_19.setHorizontalAlignment(SwingConstants.CENTER);
		label_19.setFont(new Font("����", Font.BOLD, 18));
		label_19.setBounds(496, 15, 126, 24);
		panel_3.add(label_19);
		
		
		
		
		
		
		
		
		
		
		
		
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(12, 73, 1000, 597);
		contentPane.add(tabbedPane);
		
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("\uC218\uC785", null, panel_1, null);
		panel_1.setLayout(null);
		
				
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(456, 66, 527, 479);
		panel_1.add(scrollPane);
		
		
		table = new JTable(model);
		scrollPane.setViewportView(table);
		
		btnSearch = new JButton("������ȸ");
		btnSearch.setBounds(874, 20, 97, 36);
		panel_1.add(btnSearch);
		
		tfSearch = new JTextField();
		tfSearch.setBounds(466, 20, 401, 36);
		panel_1.add(tfSearch);
		tfSearch.setColumns(10);
		
		panel = new JPanel();
		panel.setBackground(new Color(255, 228, 196));
		panel.setBounds(12, 292, 432, 253);
		panel_1.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uD56D\uBAA9\uBC88\uD638");
		lblNewLabel.setFont(new Font("����ü", Font.BOLD, 17));
		lblNewLabel.setBounds(12, 82, 69, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uB300\uD56D\uBAA9");
		lblNewLabel_1.setFont(new Font("����ü", Font.BOLD, 17));
		lblNewLabel_1.setBounds(218, 82, 57, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uD56D\uBAA9\uBA85");
		lblNewLabel_2.setFont(new Font("����ü", Font.BOLD, 17));
		lblNewLabel_2.setBounds(24, 127, 57, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\uB0A0\uC9DC");
		lblNewLabel_3.setFont(new Font("����ü", Font.BOLD, 17));
		lblNewLabel_3.setBounds(36, 171, 57, 15);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\uAE08\uC561");
		lblNewLabel_4.setFont(new Font("����ü", Font.BOLD, 17));
		lblNewLabel_4.setBounds(229, 127, 57, 15);
		panel.add(lblNewLabel_4);
		
		tfMoney_no = new JTextField();
		tfMoney_no.setBounds(89, 75, 116, 33);
		panel.add(tfMoney_no);
		tfMoney_no.setColumns(10);
		
		tfBigItem = new JTextField();
		tfBigItem.setBounds(283, 75, 116, 33);
		panel.add(tfBigItem);
		tfBigItem.setColumns(10);
		
		tfSmallItem = new JTextField();
		tfSmallItem.setBounds(89, 119, 116, 34);
		panel.add(tfSmallItem);
		tfSmallItem.setColumns(10);
		
		tfMoney = new JTextField();
		tfMoney.setBounds(89, 163, 116, 33);
		panel.add(tfMoney);
		tfMoney.setColumns(10);
		
		tfDate = new JTextField();
		tfDate.setBounds(283, 119, 116, 33);
		panel.add(tfDate);
		tfDate.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.setFont(new Font("����", Font.BOLD, 15));
		btnNewButton_1.setBounds(218, 187, 68, 35);
		panel.add(btnNewButton_1);
		
		btnUpdate = new JButton("����");
		btnUpdate.setFont(new Font("����", Font.BOLD, 13));
		btnUpdate.setBounds(287, 187, 63, 35);
		panel.add(btnUpdate);
		
		btnDelete = new JButton("����");
		btnDelete.setFont(new Font("����", Font.BOLD, 15));
		btnDelete.setBounds(352, 187, 68, 35);
		panel.add(btnDelete);
		
		
		
		JLabel label_7 = new JLabel("\uC218\uC785 \uB370\uC774\uD130 \uC785\uB825");
		label_7.setFont(new Font("����", Font.BOLD, 18));
		label_7.setBounds(13, 24, 161, 28);
		panel.add(label_7);
		
		panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(255, 228, 196));
		panel_2.setBounds(12, 10, 432, 272);
		panel_1.add(panel_2);
		
		label = new JLabel("\uCE74\uD14C\uACE0\uB9AC \uC124\uC815");
		label.setFont(new Font("����", Font.BOLD, 18));
		label.setBounds(12, 22, 121, 28);
		panel_2.add(label);
		
		button = new JButton("\uB4F1\uB85D");
		button.setFont(new Font("����", Font.BOLD, 15));
		button.setBackground(SystemColor.info);
		button.setBounds(305, 75, 64, 64);
		panel_2.add(button);
		
		label_1 = new JLabel("\uB300\uD56D\uBAA9");
		label_1.setFont(new Font("����ü", Font.BOLD, 17));
		label_1.setBounds(49, 60, 51, 36);
		panel_2.add(label_1);
		
		label_2 = new JLabel("\uD56D\uBAA9\uBA85");
		label_2.setFont(new Font("����ü", Font.BOLD, 17));
		label_2.setBounds(49, 103, 51, 36);
		panel_2.add(label_2);
		
		
		
		comboBox = new JComboBox(new Object[]{});
		comboBox.setEditable(true);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\uC8FC\uC218\uC785", "\uBD80\uC218\uC785"}));
		comboBox.setToolTipText("");
		comboBox.setBounds(112, 65, 181, 28);
		panel_2.add(comboBox);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(112, 106, 181, 33);
		panel_2.add(textField);
		
		String data [][]= {{"�ּ���","�뵷"},{"�ּ���","�˹ٺ�"},{"�μ���","���ʽ�"}};
		String col[]= {"���׸�","�׸��"};
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(49, 149, 320, 91);
		panel_2.add(scrollPane_1);
		table_1 = new JTable(data,col);
		table_1.setCellSelectionEnabled(true);
		table_1.setBounds(49, 149, 320, 95);
		scrollPane_1.setViewportView(table_1);
	
		
		
		//����
		//dao ��ü ����
		outdao=OutMoneyDAO.getoutInstance();
		//���̺��� ���� �÷� ����
		outcol=new Vector();
		outcol.add("�׸��ȣ");
		outcol.add("���׸�");
		outcol.add("�׸��");
		outcol.add("�ݾ�");
		outcol.add("��¥");
		outcol.add("�ѱݾ�");
				
				
				
		//���� ����Ʈ�� �ҷ���
		//���̺� �� : JTable�� �Էµ� ������
		//JTable �� �Է� ������ ������ :�迭(����, ������ �ȵ�), Object, Vector
		// new DefaultTableModel(������, ����)
		DefaultTableModel model1=new DefaultTableModel(outdao.outlistScore(), outcol){
					
			//���̺� ������ �������� ���ϵ��� ����
			@Override
			public boolean isCellEditable(int row1, int column1) {
						return false;
				}
		};
		panel_4 = new JPanel();
		tabbedPane.addTab("\uC9C0\uCD9C", null, panel_4, null);
		panel_4.setLayout(null);
		
		JScrollPane scrollPane1 = new JScrollPane();
		scrollPane1.setBounds(456, 66, 527, 492);
		panel_4.add(scrollPane1);
		
		
		table1 = new JTable(model1);
		scrollPane1.setViewportView(table1);
		
		JPanel panel_5 = new JPanel();
		panel_5.setLayout(null);
		panel_5.setBackground(new Color(255, 228, 196));
		panel_5.setBounds(12, 305, 432, 253);
		panel_4.add(panel_5);
		
		JLabel label_8 = new JLabel("\uD56D\uBAA9\uBC88\uD638");
		label_8.setFont(new Font("����ü", Font.BOLD, 17));
		label_8.setBounds(12, 82, 69, 15);
		panel_5.add(label_8);
		
		JLabel label_9 = new JLabel("\uB300\uD56D\uBAA9");
		label_9.setFont(new Font("����ü", Font.BOLD, 17));
		label_9.setBounds(218, 82, 57, 15);
		panel_5.add(label_9);
		
		JLabel label_10 = new JLabel("\uD56D\uBAA9\uBA85");
		label_10.setFont(new Font("����ü", Font.BOLD, 17));
		label_10.setBounds(24, 127, 57, 15);
		panel_5.add(label_10);
		
		JLabel label_11 = new JLabel("\uB0A0\uC9DC");
		label_11.setFont(new Font("����ü", Font.BOLD, 17));
		label_11.setBounds(36, 171, 57, 15);
		panel_5.add(label_11);
		
		JLabel label_12 = new JLabel("\uAE08\uC561");
		label_12.setFont(new Font("����ü", Font.BOLD, 17));
		label_12.setBounds(229, 127, 57, 15);
		panel_5.add(label_12);
	
	
		
	
		

		
		
		
		tfoMoney_no = new JTextField();
		tfoMoney_no.setColumns(10);
		tfoMoney_no.setBounds(89, 75, 116, 33);
		panel_5.add(tfoMoney_no);
		
		tfoBigItem = new JTextField();
		tfoBigItem.setColumns(10);
		tfoBigItem.setBounds(283, 75, 116, 33);
		panel_5.add(tfoBigItem);
		
		tfoSmallItem = new JTextField();
		tfoSmallItem.setColumns(10);
		tfoSmallItem.setBounds(89, 119, 116, 34);
		panel_5.add(tfoSmallItem);
		
		tfoMoney = new JTextField();
		tfoMoney.setColumns(10);
		tfoMoney.setBounds(89, 163, 116, 33);
		panel_5.add(tfoMoney);
		
		tfoDate = new JTextField();
		tfoDate.setColumns(10);
		tfoDate.setBounds(283, 119, 116, 33);
		panel_5.add(tfoDate);
		
		JButton button_1 = new JButton("����");
		button_1.setFont(new Font("����", Font.BOLD, 15));
		button_1.setBounds(218, 187, 68, 35);
		panel_5.add(button_1);
		
		btnoUpdate = new JButton("\uC218\uC815");
		btnoUpdate.setFont(new Font("����", Font.BOLD, 13));
		btnoUpdate.setBounds(287, 187, 63, 35);
		panel_5.add(btnoUpdate);
		
		btnoDelete = new JButton("\uC0AD\uC81C");
		btnoDelete.setFont(new Font("����", Font.BOLD, 15));
		btnoDelete.setBounds(352, 187, 68, 35);
		panel_5.add(btnoDelete);
		
		JLabel label_13 = new JLabel("\uC9C0\uCD9C \uB370\uC774\uD130 \uC785\uB825");
		label_13.setFont(new Font("����", Font.BOLD, 18));
		label_13.setBounds(13, 24, 161, 28);
		panel_5.add(label_13);
		
		tfoSearch = new JTextField();
		tfoSearch.setColumns(10);
		tfoSearch.setBounds(466, 23, 401, 36);
		panel_4.add(tfoSearch);
		
		btnoSearch = new JButton("������ȸ");
		btnoSearch.setBounds(874, 23, 97, 36);
		panel_4.add(btnoSearch);
		
		panel_6 = new JPanel();
		panel_6.setLayout(null);
		panel_6.setBackground(new Color(255, 228, 196));
		panel_6.setBounds(12, 10, 432, 285);
		panel_4.add(panel_6);
		
		label_14 = new JLabel("\uCE74\uD14C\uACE0\uB9AC \uC124\uC815");
		label_14.setFont(new Font("����", Font.BOLD, 18));
		label_14.setBounds(12, 22, 121, 28);
		panel_6.add(label_14);
		
		button_2 = new JButton("\uB4F1\uB85D");
		button_2.setFont(new Font("����", Font.BOLD, 15));
		button_2.setBackground(SystemColor.info);
		button_2.setBounds(305, 75, 64, 64);
		panel_6.add(button_2);
		
		label_15 = new JLabel("\uB300\uD56D\uBAA9");
		label_15.setFont(new Font("����ü", Font.BOLD, 17));
		label_15.setBounds(49, 60, 51, 36);
		panel_6.add(label_15);
		
		label_16 = new JLabel("\uD56D\uBAA9\uBA85");
		label_16.setFont(new Font("����ü", Font.BOLD, 17));
		label_16.setBounds(49, 103, 51, 36);
		panel_6.add(label_16);
		
		comboBox_1 = new JComboBox(new Object[]{});
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"\uAD50\uD1B5\uBE44", "\uC2DD\uBE44", "\uBB38\uD654\uC0DD\uD65C"}));
		comboBox_1.setEditable(true);
		comboBox_1.setBounds(112, 65, 181, 28);
		panel_6.add(comboBox_1);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(112, 106, 181, 33);
		panel_6.add(textField_4);
		
		
		String data1 [][]= {{"�����","����ö"},{"�����","����"},{"�ĺ�","��ħ��������"},{"�ĺ�","ī�����Ʈ"},{"��ȭ��Ȱ","��ȭ"}};
		String col1[]= {"���׸�","�׸��"};	
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(49, 149, 320, 113);
		panel_6.add(scrollPane_2);
		table_2 = new JTable(data1,col1);
		table_2.setCellSelectionEnabled(true);
		table_2.setBounds(49, 149, 320, 95);
		scrollPane_2.setViewportView(table_2);
		
		JPanel panel_7 = new JPanel();
		tabbedPane.addTab("\uAC80\uC0C9", null, panel_7, null);
		panel_7.setLayout(null);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(292, 10, 401, 36);
		panel_7.add(textField_5);
		
		JButton button_3 = new JButton("\uAC80 \uC0C9");
		button_3.setFont(new Font("����", Font.BOLD, 15));
		button_3.setBounds(700, 10, 97, 36);
		panel_7.add(button_3);
		
		
		sdao=SelectDAO.getInstance();
		//���̺��� ���� �÷� ����
		colcolcol=new Vector();
		
		colcolcol.add("�׸��ȣ");
		colcolcol.add("���׸�");
		colcolcol.add("�׸��");
		colcolcol.add("�ݾ�");
		colcolcol.add("��¥");
		colcolcol.add("�ѱݾ�");
				
				
				
		//���� ����Ʈ�� �ҷ���
		//���̺� �� : JTable�� �Էµ� ������
		//JTable �� �Է� ������ ������ :�迭(����, ������ �ȵ�), Object, Vector
		// new DefaultTableModel(������, ����)
		DefaultTableModel model3=new DefaultTableModel(sdao.ininlistScore(), colcolcol){
					
			//���̺� ������ �������� ���ϵ��� ����
			@Override
			public boolean isCellEditable(int row1, int column1) {
						return false;
				}
		};
		
		
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(30, 53, 939, 492);
		panel_7.add(scrollPane_3);
		
		
		
		
		
		table_3 = new JTable(model3);
		
		scrollPane_3.setViewportView(table_3);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\uAE30\uAC04\uAC80\uC0C9");
		rdbtnNewRadioButton.setFont(new Font("����ü", Font.PLAIN, 14));
		rdbtnNewRadioButton.setBounds(52, 15, 107, 23);
		panel_7.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\uD56D\uBAA9\uAC80\uC0C9");
		rdbtnNewRadioButton_1.setFont(new Font("����ü", Font.PLAIN, 14));
		rdbtnNewRadioButton_1.setBounds(158, 15, 113, 23);
		panel_7.add(rdbtnNewRadioButton_1);
		
		
		
		
		
		JPanel panel_8 = new JPanel();
		tabbedPane.addTab("\uAE30\uBCF8\uD1B5\uACC4", null, panel_8, null);
		panel_8.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("\uC218\uC785\uD1B5\uACC4");
		lblNewLabel_5.setFont(new Font("�������� ExtraBold", Font.BOLD, 18));
		lblNewLabel_5.setBounds(204, 48, 72, 39);
		panel_8.add(lblNewLabel_5);
		
		JLabel label_17 = new JLabel("\uC9C0\uCD9C\uD1B5\uACC4");
		label_17.setFont(new Font("�������� ExtraBold", Font.BOLD, 18));
		label_17.setBounds(707, 48, 72, 39);
		panel_8.add(label_17);
		
		panel_9 = new JPanel();
		panel_9.setBounds(12, 97, 477, 461);
		panel_8.add(panel_9);
		
		panel_10 = new JPanel();
		panel_10.setBounds(506, 97, 477, 461);
		panel_8.add(panel_10);
		
/*		DefaultCategoryDataset dod=new DefaultCategoryDataset();
		ChartDAO chartDAO= new ChartDAO();
		
		dod.setValue(20, "Input", "mainInput");
		dod.setValue(80, "Input", "extraInput");
		dod.setValue(10, "Output", "transportation");
		dod.setValue(30, "Output", "meal");
		dod.setValue(60, "Output", "culture");
		JFreeChart jchart=ChartFactory.createBarChart("", "Input / Output", "record", dod,PlotOrientation.VERTICAL,true,true,false);
		CategoryPlot plot=jchart.getCategoryPlot();
		plot.setRangeGridlinePaint(Color.black);
		
		ChartPanel chartpanel=new ChartPanel(jchart);
		panel_9.removeAll();
		panel_9.add(chartpanel);
		panel_9.updateUI();
*/
		chartdao=new ChartDAO();
		
		DefaultPieDataset pieDataset=new DefaultPieDataset();
		try
		{
			pieDataset.setValue("yongdon",(Number) (chartdao.valueval()).get(0));
			pieDataset.setValue("alba", (Number) (chartdao.valueval()).get(1));
			pieDataset.setValue("bonus", (Number) (chartdao.valueval()).get(2));
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			chartdao.valueval().add(0);
		}
		//System.out.print((chartdao.valueval()).get(0));
		
		JFreeChart chart=ChartFactory.createPieChart("", pieDataset, true, true, true);
		PiePlot p=(PiePlot)chart.getPlot();
		//p.setForegroundAlpha(TOP_ALIGNMENT);

		ChartPanel chartpanel=new ChartPanel(chart);
		panel_9.removeAll();
		panel_9.add(chartpanel);
		
		
		
		DefaultPieDataset pieDataset1=new DefaultPieDataset();
		
		try
		{
			pieDataset1.setValue("bus", (Number) (chartdao.valueval2()).get(0));
			pieDataset1.setValue("subway",(Number) (chartdao.valueval2()).get(1));
			pieDataset1.setValue("meal", (Number) (chartdao.valueval2()).get(2));
			pieDataset1.setValue("cafe", (Number) (chartdao.valueval2()).get(3));
			pieDataset1.setValue("culture", (Number) (chartdao.valueval2()).get(4));
			
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			chartdao.valueval2().add(0);
		}
		
		JFreeChart chart1=ChartFactory.createPieChart("", pieDataset1, true, true, true);
		PiePlot p1=(PiePlot)chart1.getPlot();
		
		ChartPanel chartpanel1=new ChartPanel(chart1);
		panel_10.removeAll();
		panel_10.add(chartpanel1);
		
		
		
		
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						
			int result=outdao.outinsertScore(outtextInput());
			
			outrefresh(result , "����");
			label_18.setText(Integer.toString(totdao.OutputSum()));
			label_19.setText(Integer.toString(totdao.InputSum()-totdao.OutputSum()));	
			DefaultPieDataset pieDataset=new DefaultPieDataset();
			try
			{
				pieDataset.setValue("yongdon",(Number) (chartdao.valueval()).get(0));
				pieDataset.setValue("alba", (Number) (chartdao.valueval()).get(1));
				pieDataset.setValue("bonus", (Number) (chartdao.valueval()).get(2));
			}
			catch(ArrayIndexOutOfBoundsException e1)
			{
				chartdao.valueval().add(0);
			}
			//System.out.print((chartdao.valueval()).get(0));
			
			JFreeChart chart=ChartFactory.createPieChart("", pieDataset, true, true, true);
			PiePlot p=(PiePlot)chart.getPlot();
			//p.setForegroundAlpha(TOP_ALIGNMENT);

			ChartPanel chartpanel=new ChartPanel(chart);
			panel_9.removeAll();
			panel_9.add(chartpanel);
			
			
			
			DefaultPieDataset pieDataset1=new DefaultPieDataset();
			
			try
			{
				pieDataset1.setValue("bus", (Number) (chartdao.valueval2()).get(0));
				pieDataset1.setValue("subway",(Number) (chartdao.valueval2()).get(1));
				pieDataset1.setValue("meal", (Number) (chartdao.valueval2()).get(2));
				pieDataset1.setValue("cafe", (Number) (chartdao.valueval2()).get(3));
				pieDataset1.setValue("culture", (Number) (chartdao.valueval2()).get(4));
				
			}
			catch(ArrayIndexOutOfBoundsException e1)
			{
				chartdao.valueval2().add(0);
			}
			
			JFreeChart chart1=ChartFactory.createPieChart("", pieDataset1, true, true, true);
			PiePlot p1=(PiePlot)chart1.getPlot();
			
			ChartPanel chartpanel1=new ChartPanel(chart1);
			panel_10.removeAll();
			panel_10.add(chartpanel1);
			}
		});
		
		btnoDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
			int response=JOptionPane.showConfirmDialog(MoneyList.this, "���� �Ͻðڽ��ϱ�?");
						
			if(response==JOptionPane.YES_OPTION){ //yes Ŭ����
					OutMoneyDTO dto =outtextInput();
					int result=outdao.outdeleteScore(dto.getoutMoney_no());
							
					outrefresh(result, "����");
					label_18.setText(Integer.toString(totdao.OutputSum()));			
					label_19.setText(Integer.toString(totdao.InputSum()-totdao.OutputSum()));	
					DefaultPieDataset pieDataset=new DefaultPieDataset();
					try
					{
						pieDataset.setValue("yongdon",(Number) (chartdao.valueval()).get(0));
						pieDataset.setValue("alba", (Number) (chartdao.valueval()).get(1));
						pieDataset.setValue("bonus", (Number) (chartdao.valueval()).get(2));
					}
					catch(ArrayIndexOutOfBoundsException e3)
					{
						chartdao.valueval().add(0);
					}
					//System.out.print((chartdao.valueval()).get(0));
					
					JFreeChart chart=ChartFactory.createPieChart("", pieDataset, true, true, true);
					PiePlot p=(PiePlot)chart.getPlot();
					//p.setForegroundAlpha(TOP_ALIGNMENT);

					ChartPanel chartpanel=new ChartPanel(chart);
					panel_9.removeAll();
					panel_9.add(chartpanel);
					
					
					
					DefaultPieDataset pieDataset1=new DefaultPieDataset();
					
					try
					{
						pieDataset1.setValue("bus", (Number) (chartdao.valueval2()).get(0));
						pieDataset1.setValue("subway",(Number) (chartdao.valueval2()).get(1));
						pieDataset1.setValue("meal", (Number) (chartdao.valueval2()).get(2));
						pieDataset1.setValue("cafe", (Number) (chartdao.valueval2()).get(3));
						pieDataset1.setValue("culture", (Number) (chartdao.valueval2()).get(4));
						
					}
					catch(ArrayIndexOutOfBoundsException e3)
					{
						chartdao.valueval2().add(0);
					}
					
					JFreeChart chart1=ChartFactory.createPieChart("", pieDataset1, true, true, true);
					PiePlot p1=(PiePlot)chart1.getPlot();
					
					ChartPanel chartpanel1=new ChartPanel(chart1);
					panel_10.removeAll();
					panel_10.add(chartpanel1);
				}
						
			}
		});
				
		btnoUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
				int result=outdao.outupdateScore(outtextInput());
						
				outrefresh(result, "����");
				label_18.setText(Integer.toString(totdao.OutputSum()));	
				label_19.setText(Integer.toString(totdao.InputSum()-totdao.OutputSum()));
				DefaultPieDataset pieDataset=new DefaultPieDataset();
				try
				{
					pieDataset.setValue("yongdon",(Number) (chartdao.valueval()).get(0));
					pieDataset.setValue("alba", (Number) (chartdao.valueval()).get(1));
					pieDataset.setValue("bonus", (Number) (chartdao.valueval()).get(2));
				}
				catch(ArrayIndexOutOfBoundsException e2)
				{
					chartdao.valueval().add(0);
				}
				//System.out.print((chartdao.valueval()).get(0));
				
				JFreeChart chart=ChartFactory.createPieChart("", pieDataset, true, true, true);
				PiePlot p=(PiePlot)chart.getPlot();
				//p.setForegroundAlpha(TOP_ALIGNMENT);

				ChartPanel chartpanel=new ChartPanel(chart);
				panel_9.removeAll();
				panel_9.add(chartpanel);
				
				
				
				DefaultPieDataset pieDataset1=new DefaultPieDataset();
				
				try
				{
					pieDataset1.setValue("bus", (Number) (chartdao.valueval2()).get(0));
					pieDataset1.setValue("subway",(Number) (chartdao.valueval2()).get(1));
					pieDataset1.setValue("meal", (Number) (chartdao.valueval2()).get(2));
					pieDataset1.setValue("cafe", (Number) (chartdao.valueval2()).get(3));
					pieDataset1.setValue("culture", (Number) (chartdao.valueval2()).get(4));
					
				}
				catch(ArrayIndexOutOfBoundsException e2)
				{
					chartdao.valueval2().add(0);
				}
				
				JFreeChart chart1=ChartFactory.createPieChart("", pieDataset1, true, true, true);
				PiePlot p1=(PiePlot)chart1.getPlot();
				
				ChartPanel chartpanel1=new ChartPanel(chart1);
				panel_10.removeAll();
				panel_10.add(chartpanel1);
			}
		});
				
		btnoSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						
						
						//���̺� ���� ����
				DefaultTableModel model1=new DefaultTableModel(outdao.outsearchScore(tfoSearch.getText()), outcol){
							
							//���̺� ������ �������� ���ϵ��� ����
					@Override
					public boolean isCellEditable(int row1, int column1) {
						
						return false;
					}
				};
						//���̺��� ���� ����
				table1.setModel(model1);
						
			}
		});
				
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						
				int result=dao.insertScore(textInput());
				
				refresh(result , "����");
				lblNewLabel_6.setText(Integer.toString(totdao.InputSum()));
				label_19.setText(Integer.toString(totdao.InputSum()-totdao.OutputSum()));	
				DefaultPieDataset pieDataset=new DefaultPieDataset();
				try
				{
					pieDataset.setValue("yongdon",(Number) (chartdao.valueval()).get(0));
					pieDataset.setValue("alba", (Number) (chartdao.valueval()).get(1));
					pieDataset.setValue("bonus", (Number) (chartdao.valueval()).get(2));
				}
				catch(ArrayIndexOutOfBoundsException e4)
				{
					chartdao.valueval().add(0);
				}
				//System.out.print((chartdao.valueval()).get(0));
				
				JFreeChart chart=ChartFactory.createPieChart("", pieDataset, true, true, true);
				PiePlot p=(PiePlot)chart.getPlot();
				//p.setForegroundAlpha(TOP_ALIGNMENT);

				ChartPanel chartpanel=new ChartPanel(chart);
				panel_9.removeAll();
				panel_9.add(chartpanel);
				
				
				
				DefaultPieDataset pieDataset1=new DefaultPieDataset();
				
				try
				{
					pieDataset1.setValue("bus", (Number) (chartdao.valueval2()).get(0));
					pieDataset1.setValue("subway",(Number) (chartdao.valueval2()).get(1));
					pieDataset1.setValue("meal", (Number) (chartdao.valueval2()).get(2));
					pieDataset1.setValue("cafe", (Number) (chartdao.valueval2()).get(3));
					pieDataset1.setValue("culture", (Number) (chartdao.valueval2()).get(4));
					
				}
				catch(ArrayIndexOutOfBoundsException e4)
				{
					chartdao.valueval2().add(0);
				}
				
				JFreeChart chart1=ChartFactory.createPieChart("", pieDataset1, true, true, true);
				PiePlot p1=(PiePlot)chart1.getPlot();
				
				ChartPanel chartpanel1=new ChartPanel(chart1);
				panel_10.removeAll();
				panel_10.add(chartpanel1);
			}
		});
				
		
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
				int response=JOptionPane.showConfirmDialog(MoneyList.this, "���� �Ͻðڽ��ϱ�?");
						
				if(response==JOptionPane.YES_OPTION){ //yes Ŭ����
					MoneyDTO dto =textInput();
					int result=dao.deleteScore(dto.getMoney_no());
					
					refresh(result, "����");
					lblNewLabel_6.setText(Integer.toString(totdao.InputSum()));
					label_19.setText(Integer.toString(totdao.InputSum()-totdao.OutputSum()));
					
					DefaultPieDataset pieDataset=new DefaultPieDataset();
					try
					{
						pieDataset.setValue("yongdon",(Number) (chartdao.valueval()).get(0));
						pieDataset.setValue("alba", (Number) (chartdao.valueval()).get(1));
						pieDataset.setValue("bonus", (Number) (chartdao.valueval()).get(2));
					}
					catch(ArrayIndexOutOfBoundsException e5)
					{
						chartdao.valueval().add(0);
					}
					//System.out.print((chartdao.valueval()).get(0));
					
					JFreeChart chart=ChartFactory.createPieChart("", pieDataset, true, true, true);
					PiePlot p=(PiePlot)chart.getPlot();
					//p.setForegroundAlpha(TOP_ALIGNMENT);

					ChartPanel chartpanel=new ChartPanel(chart);
					panel_9.removeAll();
					panel_9.add(chartpanel);
					
					
					
					DefaultPieDataset pieDataset1=new DefaultPieDataset();
					
					try
					{
						pieDataset1.setValue("bus", (Number) (chartdao.valueval2()).get(0));
						pieDataset1.setValue("subway",(Number) (chartdao.valueval2()).get(1));
						pieDataset1.setValue("meal", (Number) (chartdao.valueval2()).get(2));
						pieDataset1.setValue("cafe", (Number) (chartdao.valueval2()).get(3));
						pieDataset1.setValue("culture", (Number) (chartdao.valueval2()).get(4));
						
					}
					catch(ArrayIndexOutOfBoundsException e5)
					{
						chartdao.valueval2().add(0);
					}
					
					JFreeChart chart1=ChartFactory.createPieChart("", pieDataset1, true, true, true);
					PiePlot p1=(PiePlot)chart1.getPlot();
					
					ChartPanel chartpanel1=new ChartPanel(chart1);
					panel_10.removeAll();
					panel_10.add(chartpanel1);
								
				}
						
			}
		});
				
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
				int result=dao.updateScore(textInput());
				
				refresh(result, "����");
				lblNewLabel_6.setText(Integer.toString(totdao.InputSum()));
				label_19.setText(Integer.toString(totdao.InputSum()-totdao.OutputSum()));
				DefaultPieDataset pieDataset=new DefaultPieDataset();
				try
				{
					pieDataset.setValue("yongdon",(Number) (chartdao.valueval()).get(0));
					pieDataset.setValue("alba", (Number) (chartdao.valueval()).get(1));
					pieDataset.setValue("bonus", (Number) (chartdao.valueval()).get(2));
				}
				catch(ArrayIndexOutOfBoundsException e6)
				{
					chartdao.valueval().add(0);
				}
				//System.out.print((chartdao.valueval()).get(0));
				
				JFreeChart chart=ChartFactory.createPieChart("", pieDataset, true, true, true);
				PiePlot p=(PiePlot)chart.getPlot();
				//p.setForegroundAlpha(TOP_ALIGNMENT);

				ChartPanel chartpanel=new ChartPanel(chart);
				panel_9.removeAll();
				panel_9.add(chartpanel);
				
				
				
				DefaultPieDataset pieDataset1=new DefaultPieDataset();
				
				try
				{
					pieDataset1.setValue("bus", (Number) (chartdao.valueval2()).get(0));
					pieDataset1.setValue("subway",(Number) (chartdao.valueval2()).get(1));
					pieDataset1.setValue("meal", (Number) (chartdao.valueval2()).get(2));
					pieDataset1.setValue("cafe", (Number) (chartdao.valueval2()).get(3));
					pieDataset1.setValue("culture", (Number) (chartdao.valueval2()).get(4));
					
				}
				catch(ArrayIndexOutOfBoundsException e6)
				{
					chartdao.valueval2().add(0);
				}
				
				JFreeChart chart1=ChartFactory.createPieChart("", pieDataset1, true, true, true);
				PiePlot p1=(PiePlot)chart1.getPlot();
				
				ChartPanel chartpanel1=new ChartPanel(chart1);
				panel_10.removeAll();
				panel_10.add(chartpanel1);
						
			}
		});
				
				
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						
						
						//���̺� ���� ����
				DefaultTableModel model=new DefaultTableModel(){
							
							//���̺� ������ �������� ���ϵ��� ����
					@Override
					public boolean isCellEditable(int row, int column) {
						return false;
					}
				};
						//���̺��� ���� ����
				table.setModel(model);
						
			}
		});
				//JTable�� ���콺 �̺�Ʈ �߰�
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//���콺 Ŭ���� ���� �ε��� ��
				int idx=table.getSelectedRow();
						//���̺�.getValueAt(���� �ε��� , �÷��� �ε���)
				tfMoney_no.setText(table.getValueAt(idx, 0)+"");
				tfBigItem.setText(table.getValueAt(idx, 1)+"");
				tfSmallItem.setText(table.getValueAt(idx, 2)+"");
				tfMoney.setText(table.getValueAt(idx, 4)+"");
				tfDate.setText(table.getValueAt(idx, 3)+"");
			}
		});
			
			
			
				
				//JTable�� ���콺 �̺�Ʈ �߰�
		table1.addMouseListener(new MouseAdapter() {
					@Override
			public void mouseClicked(MouseEvent e) {
						//���콺 Ŭ���� ���� �ε��� ��
				int idx=table1.getSelectedRow();
						//���̺�.getValueAt(���� �ε��� , �÷��� �ε���)
				tfoMoney_no.setText(table1.getValueAt(idx, 0)+"");
				tfoBigItem.setText(table1.getValueAt(idx, 1)+"");
				tfoSmallItem.setText(table1.getValueAt(idx, 2)+"");
				tfoMoney.setText(table1.getValueAt(idx, 4)+"");
				tfoDate.setText(table1.getValueAt(idx, 3)+"");
			}
		});
			
}
			
			//�ؽ�Ʈ �� ��������
		private OutMoneyDTO outtextInput(){
				//����ڰ� �Է��� ��
				OutMoneyDTO dto=new OutMoneyDTO();
				dto.setoutMoney_no(tfoMoney_no.getText());
				dto.setoutBigItem(tfoBigItem.getText());
				dto.setoutSmallItem(tfoSmallItem.getText());
				dto.setoutMoney(Integer.valueOf(tfoMoney.getText()));
				dto.setoutDate(tfoDate.getText());
				
				return dto;
			}
			private MoneyDTO textInput(){
				//����ڰ� �Է��� ��
				MoneyDTO dto=new MoneyDTO();
				dto.setMoney_no(tfMoney_no.getText());
				dto.setBigItem(tfBigItem.getText());
				dto.setSmallItem(tfSmallItem.getText());
				dto.setMoney(Integer.valueOf(tfMoney.getText()));
				dto.setDate(tfDate.getText());
				
				return dto;
			}
			
			//�޽��� ���Ϸα� ���� �� ����
			private void outrefresh(int result , String str){
				if(result==1){//insert �����ϸ� 1�� ����
					JOptionPane.showMessageDialog(MoneyList.this, str+" �Ǿ����ϴ�");
					//���̺� ���� ����
					DefaultTableModel model1=new DefaultTableModel(outdao.outlistScore(), outcol){
						
						//���̺� ������ �������� ���ϵ��� ����
						@Override
						public boolean isCellEditable(int row1, int column1) {
							return false;
						}
					};
					DefaultTableModel model3=new DefaultTableModel(sdao.ininlistScore(), colcolcol){
						
						//���̺� ������ �������� ���ϵ��� ����
						@Override
						public boolean isCellEditable(int row1, int column1) {
									return false;
							}
					};
					
					//���̺��� ���� ����
					table1.setModel(model1);
					table_3.setModel(model3);
					
					
					//�Է¶� �ʱ�ȭ
					tfoMoney_no.setText("");
					tfoBigItem.setText("");
					tfoSmallItem.setText("");
					tfoMoney.setText("");
					tfoDate.setText("");
					tfoMoney_no.setFocusable(true);
					tfoMoney_no.requestFocus();//�Է���Ŀ���� �̵���Ŵ
				}else{
					JOptionPane.showMessageDialog(MoneyList.this, str+"�� ���� �Ͽ����ϴ�.");
				}
			}
			private void refresh(int result , String str){
					if(result==1){//insert �����ϸ� 1�� ����
						JOptionPane.showMessageDialog(MoneyList.this, str+" �Ǿ����ϴ�");
						
						//���̺� ���� ����
						DefaultTableModel model=new DefaultTableModel(dao.listScore(), col){
							
							//���̺� ������ �������� ���ϵ��� ����
							@Override
							public boolean isCellEditable(int row, int column) {
								return false;
							}
						};
						DefaultTableModel model3=new DefaultTableModel(sdao.ininlistScore(), colcolcol){
							
							//���̺� ������ �������� ���ϵ��� ����
							@Override
							public boolean isCellEditable(int row1, int column1) {
										return false;
								}
						};
						//���̺��� ���� ����
						table.setModel(model);
						table_3.setModel(model3);
						
						//�Է¶� �ʱ�ȭ
						tfMoney_no.setText("");
						tfBigItem.setText("");
						tfSmallItem.setText("");
						tfMoney.setText("");
						tfDate.setText("");
						tfMoney_no.setFocusable(true);
						tfMoney_no.requestFocus();//�Է���Ŀ���� �̵���Ŵ
						
					}else{
						JOptionPane.showMessageDialog(MoneyList.this, str+"�� ���� �Ͽ����ϴ�.");
					}
					
					
				
				}	
}
