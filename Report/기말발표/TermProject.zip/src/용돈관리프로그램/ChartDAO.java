package �뵷�������α׷�;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import DB.DBConnectManager;

public class ChartDAO {

	private static ChartDAO chartdao;
	ChartDAO()
	{
		
	}
	public static ChartDAO getInstance(){
		if(chartdao==null){
			chartdao =new ChartDAO();
		}
		return chartdao;
	}
	
	public static Vector valueval()
	{
		int st=0;
		Vector <Integer> vc=new Vector<Integer>();
		
		Connection connn=null;
		PreparedStatement pstmtpstmt=null;
		ResultSet rsrs=null;
		
		try
		{
			connn=DBConnectManager.dbConn();
			String sqlsql=" select ROUND(SUM(DATE)/SUM(SUM(DATE))OVER()*100,2) RAT_SAL FROM moneyin GROUP BY bigitem, smallitem;";
			pstmtpstmt=connn.prepareStatement(sqlsql);
			rsrs=pstmtpstmt.executeQuery();
			while (rsrs.next())
			{
				
				int inputsum=rsrs.getInt("RAT_SAL");
				
			
				
				vc.add(inputsum);
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DBConnectManager.close(connn,pstmtpstmt,rsrs);
		}
		return vc;
	}
	
	
	
	public static Vector valueval2()
	{
		
		Vector <Integer> vc2=new Vector<Integer>();
		
		Connection connn1=null;
		PreparedStatement pstmtpstmt1=null;
		ResultSet rsrs1=null;
		
		try
		{
			connn1=DBConnectManager.dbConn();
			String sqlsql=" select ROUND(SUM(outDATE)/SUM(SUM(outDATE))OVER()*100,2) RAT_SAL FROM moneyout GROUP BY outbigitem, outsmallitem;";
			pstmtpstmt1=connn1.prepareStatement(sqlsql);
			rsrs1=pstmtpstmt1.executeQuery();
			while (rsrs1.next())
			{
				
				int inputsum=rsrs1.getInt("RAT_SAL");
				
				vc2.add(inputsum);
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DBConnectManager.close(connn1,pstmtpstmt1,rsrs1);
		}
		return vc2;
	}
	
}
